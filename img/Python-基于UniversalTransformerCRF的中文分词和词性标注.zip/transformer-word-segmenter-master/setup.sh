pip install git+https://github.com/GlassyWing/keras-transformer.git
python setup.py sdist
cd dist
pip install transformer-word-segmenter-0.1-SNAPSHOT.tar.gz