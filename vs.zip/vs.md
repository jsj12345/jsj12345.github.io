```python
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import re
```


```python


def convert_spaces_to_tabs(input_file, output_file):
    """
    将空格分隔的表格转换为制表符分隔格式
    :param input_file: 输入文件名
    :param output_file: 输出文件名
    """
    with open(input_file, 'r') as f_in, open(output_file, 'w') as f_out:
        for line in f_in:
            # 将连续两个及以上空格替换为制表符
            cleaned_line = re.sub(r' {2,}', '\t', line.strip())
            f_out.write(cleaned_line + '\n')

# 使用示例
convert_spaces_to_tabs('clumped_results.clumped', 'clumped_results.clumped.norm')

```


```python

# 假设gwas_data是包含所有SNP的DataFrame，包含列：CHR, POS, P, SNP_ID
# 假设clumped_snps是独立信号SNP的列表（lead SNPs）
clumped=pd.read_csv("clumped_results.clumped.norm",sep='\t')
gwas_data=pd.read_csv("my_gwas.assoc.txt",sep='\t')
```


```python
clumped
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>CHR</th>
      <th>F</th>
      <th>SNP</th>
      <th>BP</th>
      <th>P</th>
      <th>TOTAL</th>
      <th>NSIG</th>
      <th>S05</th>
      <th>S01</th>
      <th>S001</th>
      <th>S0001</th>
      <th>SP2</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>1</td>
      <td>2:55587876:T:C</td>
      <td>55587876.0</td>
      <td>9.830000e-16</td>
      <td>25</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>25 2:55494904:C:G(1),2:55500529:A:G(1),2:55502...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20</td>
      <td>1</td>
      <td>20:42758834:T:C</td>
      <td>42758834.0</td>
      <td>7.900000e-15</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>4 20:42748383:G:A(1),20:42751035:T:C(1),20:427...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>1</td>
      <td>1:167562605:G:A</td>
      <td>167562605.0</td>
      <td>1.420000e-14</td>
      <td>8</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>8 1:167546221:T:C(1),1:167548962:T:C(1),1:1675...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7</td>
      <td>1</td>
      <td>7:134326056:G:T</td>
      <td>134326056.0</td>
      <td>1.210000e-12</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5 7:134312493:A:G(1),7:134355426:G:T(1),7:1343...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>1</td>
      <td>2:55508333:G:C</td>
      <td>55508333.0</td>
      <td>8.520000e-12</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>378810</th>
      <td>11</td>
      <td>1</td>
      <td>11:95249340:T:C</td>
      <td>95249340.0</td>
      <td>1.000000e+00</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>378811</th>
      <td>1</td>
      <td>1</td>
      <td>1:44123074:A:G</td>
      <td>44123074.0</td>
      <td>1.000000e+00</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>378812</th>
      <td>8</td>
      <td>1</td>
      <td>8:87612144:C:T</td>
      <td>87612144.0</td>
      <td>1.000000e+00</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>378813</th>
      <td>11</td>
      <td>1</td>
      <td>11:21582709:A:G</td>
      <td>21582709.0</td>
      <td>1.000000e+00</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>378814</th>
      <td>14</td>
      <td>1</td>
      <td>14:67936045:A:G</td>
      <td>67936045.0</td>
      <td>1.000000e+00</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0 NONE</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>378815 rows × 12 columns</p>
</div>




```python
# 计算每个SNP的-log10(P)
gwas_data['logP'] = -np.log10(gwas_data['P'])
clumped_snps=clumped['SNP']
# 为每个染色体分配颜色（交替）
gwas_data['color'] = np.where(gwas_data['CHR'] % 2 == 1, '#1f77b4', '#ff7f0e')

# 创建全局位置（连续）
chrom_offsets = {}
cum_pos = 0
for chrom in sorted(gwas_data['CHR'].unique()):
    chrom_offsets[chrom] = cum_pos
    cum_pos += gwas_data[gwas_data['CHR']==chrom]['BP'].max()
gwas_data['global_pos'] = gwas_data.apply(lambda row: chrom_offsets[row['CHR']] + row['BP'], axis=1)

# 绘制曼哈顿图
plt.figure(figsize=(14, 5))
plt.scatter(gwas_data['global_pos'], gwas_data['logP'], 
            c=gwas_data['color'], s=2, alpha=0.6)

# 高亮独立信号（clumping得到的lead SNPs）
clumped_data = gwas_data[gwas_data['SNP'].isin(clumped_snps)]
plt.scatter(clumped_data['global_pos'], clumped_data['logP'], 
            color='red', s=30, zorder=5, 
            edgecolors='black', label='Lead SNPs (LD clumping)')
clumped_data_obs=clumped_data[clumped_data['logP']>-np.log10(5e-8)]
plt.scatter(clumped_data_obs['global_pos'], clumped_data_obs['logP'], 
            color='yellow', s=50, zorder=5, 
            edgecolors='blue', label='Lead SNPs (LD clumping)obs')
# 添加显著线
plt.axhline(y=-np.log10(5e-8), color='r', linestyle='--', linewidth=1)
plt.axhline(y=-np.log10(1e-5), color='blue', linestyle=':', linewidth=1)

# 设置x轴为染色体标签
chrom_centers = [chrom_offsets[c] + gwas_data[gwas_data['CHR']==c]['BP'].median() for c in sorted(chrom_offsets)]
plt.xticks(chrom_centers, sorted(chrom_offsets.keys()))
plt.xlabel('Chromosome')
plt.ylabel('$-\log_{10}(p)$')
plt.title('Manhattan Plot with LD Clumping Results')
plt.legend()
plt.tight_layout()
plt.savefig('LD_clumping.png')
plt.show()


```

    C:\Users\Administrator\AppData\Local\Temp\ipykernel_30944\2440510483.py:40: UserWarning: Creating legend with loc="best" can be slow with large amounts of data.
      plt.tight_layout()
    C:\Users\Administrator\AppData\Local\Temp\ipykernel_30944\2440510483.py:41: UserWarning: Creating legend with loc="best" can be slow with large amounts of data.
      plt.savefig('LD_clumping.png')
    d:\ProgramData\anaconda3\envs\py123\lib\site-packages\IPython\core\pylabtools.py:170: UserWarning: Creating legend with loc="best" can be slow with large amounts of data.
      fig.canvas.print_figure(bytes_io, **kw)
    


    
![png](output_4_1.png)
    

